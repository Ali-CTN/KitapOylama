﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class LoginController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Users model)
        {
            if (ModelState.IsValid)
            {
                Users user = dB.Users.FirstOrDefault(x => x.Username == model.Username && x.Userpassword == model.Userpassword);


                if (user != null)
                {
                    if (user.Role == 0)
                    {
                        Session.Add("CurrentUser", user.Username);
                        Session.Add("CurrentUserId", user.Id);
                        Session.Add("CurrentUserIsAdmin", user.Role);
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        Session.Add("CurrentUser", user.Username);
                        Session.Add("CurrentUserId", user.Id);
                        Session.Add("CurrentUserIsAdmin", user.Role);

                        return RedirectToAction("Index", "Category");
                    }

                }
                else
                {
                    
                    ViewBag.msg = " Bu Kullanıcı Mevcut Değil";
                }
            }


            return View(model);
        }

        public ActionResult Logout()
        {
            Session.RemoveAll();

            return RedirectToAction("Index", "Home");
        }

        public ActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        
        public ActionResult Signup([Bind(Include = "Email,UserName,UserPassword,Role")] Users user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    user.Role = 0;
                    dB.Users.Add(user);
                    dB.SaveChanges();
                    return RedirectToAction("Index", "Home");
                }
                catch (Exception ex)
                {
                    @ViewBag.msg = "Eksik parametre girildi.";
                }
            }

            return View(user);
        }
    }
}