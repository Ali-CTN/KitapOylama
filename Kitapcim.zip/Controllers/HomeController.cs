﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;



namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Home
        public ActionResult Index(int? id)
        {
            
            BookList x = new BookList();
            x.categories = dB.Category.ToList();
            x.books = dB.Books.ToList();

           




                if (id.HasValue)
            {
                x.books = x.books.Where(p => p.Categoryıd == id).ToList();
            }

            return View(x);

        }
       


        [HttpGet]
        public ActionResult IndexDetay(int id)
        {
            return View(dB.Books.Where(x => x.ıd == id).FirstOrDefault());

        }
        [HttpGet]
        [ChildActionOnly]
        public PartialViewResult YorumYap(int? id)
        {

            return PartialView();

        }

        [HttpPost]
        public ActionResult YorumYap(Comments comment)
        {
            comment.Approvel = 0;
            comment.Userıd = Convert.ToInt32(Session["CurrentUserId"]);

            

            dB.Comments.Add(comment);
            dB.SaveChanges();
            //return PartialView();
            return RedirectToAction("Index");


        }

            
                       
        

    } 
}