﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class CommentsController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Comments
        public ActionResult Index()
        {
            var x = dB.Comments.ToList();
            return View(x);
        }
        
        public ActionResult Edit(int? id)
        {
            
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comments comment = dB.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
           
            return View(comment);
            

        }
        


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ıd,Approvel")] Comments comment)
        {


            
            if (ModelState.IsValid)
            {   
                var xx = dB.Comments.Where(w => w.ıd == comment.ıd).FirstOrDefault();
                xx.Approvel = comment.Approvel;
                
                
                dB.SaveChanges();
                return RedirectToAction("Index");
            }

            
            return View(comment);
            

        }


    }
}