﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;



namespace $safeprojectname$.Controllers
{
    public class UserController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Users
        public ActionResult Index()
        {
            {
                var x = dB.Users.ToList();
                return View(x);
            }
        }
        
            [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            }
            Users kullanıcı = dB.Users.Find(id);
            if (kullanıcı == null)
            {
                return HttpNotFound();
            }


            return View(kullanıcı);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Role")] Users kullanıcı)
        {
            if (ModelState.IsValid)
            {
                var a = dB.Users.Where(w => w.Id == kullanıcı.Id).FirstOrDefault();
                a.Role = kullanıcı.Role;
               
                dB.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(kullanıcı);
        }

        public ActionResult Delete(int id)
        {
            var a = dB.Users.Find(id);
            dB.Users.Remove(a);
            dB.SaveChanges();
            return RedirectToAction("Index");
        }
    }
    }
