﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class CategoryController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Category
        public ActionResult Index()
        {
            var x = dB.Category.ToList();
            return View(x);
        }
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            }
            Category kitap = dB.Category.Find(id);
            if (kitap == null)
            {
                return HttpNotFound();
            }


            return View(kitap);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ıd,Categorynames")] Category kitap)
        {
            if (ModelState.IsValid)
            {
                dB.Entry(kitap).State = EntityState.Modified;
                dB.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(kitap);
        }
        [HttpGet]
        public ActionResult Create()
        {
            
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ıd,Categorynames")] Category kitap)
        {
            if (ModelState.IsValid)
            {


                dB.Category.Add(kitap);
                dB.SaveChanges();
                return RedirectToAction("Index");


            }

            return View(kitap);
        }

        public ActionResult Delete(int id)
        {
            var x = dB.Category.Find(id);
            dB.Category.Remove(x);
            dB.SaveChanges();
            return RedirectToAction("Index"); 
        }

    }
}