﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class BooksController : Controller
    {
        DB_KitapcimEntities1 dB = new DB_KitapcimEntities1();
        // GET: Books
        public ActionResult Index()
        {
            var x = dB.Books.ToList();
            return View(x);
        }
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            var book = dB.Books.Find(id);

            List<SelectListItem> degerler = (from i in dB.Category.ToList()
                                             select new SelectListItem
                                             {
                                                 Text = i.Categorynames,
                                                 Value = i.ıd.ToString()
                                             }).ToList();
            ViewBag.dgr = degerler;
            return View("Edit", book);
        }

        public ActionResult Update(Books Güncel)
        {
            var book = dB.Books.Find(Güncel.ıd);
            book.Booknames = Güncel.Booknames;
            book.Bookauthor = Güncel.Bookauthor;
            book.Bookinfo = Güncel.Bookinfo;
            book.İmage = Güncel.İmage;

            var books = dB.Category.Where(m => m.ıd == Güncel.Category.ıd).FirstOrDefault();
            book.Categoryıd = books.ıd;
            dB.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            var a = dB.Books.Find(id);
            dB.Books.Remove(a);
            dB.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Create(int? ıd)
        {
            List<SelectListItem> degerler = (from i in dB.Category.ToList()
                                             select new SelectListItem
                                             {
                                                 Text = i.Categorynames,
                                                 Value = i.ıd.ToString()
                                             }).ToList();
            ViewBag.dgr = degerler;
            return View();

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Books newbook)
        {
            var Ctg = dB.Category.Where(m => m.ıd == newbook.Category.ıd).FirstOrDefault();
            newbook.Category = Ctg;
            dB.Books.Add(newbook);
            dB.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}

